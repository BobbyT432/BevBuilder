var express = require('express');
const User = require('../models/user');
var router = express.Router();

const sessionChecker = (req, res, next)=> {
    if(req.session.user) {
      next()
    } else {
      res.redirect("/?msg=raf")
    }
}

router.use(sessionChecker)

router.get('/', function(req, res, next) {
    console.log("User Session:")
    console.log(req.session.user)
    res.render('index', { title: 'Express' });
});
  
module.exports = router;
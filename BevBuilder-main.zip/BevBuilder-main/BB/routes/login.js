var express = require('express');
const User = require('../models/user')
var router = express.Router();

router.get('/login', function(req, res, next) {
    res.render('login')
});

module.exports = router;